const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

// ===============================
// MIDDLEWARE
// ===============================

app.use(cors());
app.use(express.json());

// ===============================
// PLANT DATA
// ===============================

const plants = [
  {
    id: 1,
    name: "Aloe Vera",
    scientificName: "Aloe barbadensis miller",
    environment: "indoor",
    sun: "medium",
    water: "low",
    difficulty: "easy",
    benefits: "Medicinal and air purifying",
    symptoms: ["yellow leaves", "wilting"],
    solution: "Avoid overwatering and provide bright indirect light",
    tags: ["Medicinal", "Easy Care"],
    emoji: "🌿"
  },

  {
    id: 2,
    name: "Snake Plant",
    scientificName: "Dracaena trifasciata",
    environment: "indoor",
    sun: "low",
    water: "low",
    difficulty: "easy",
    benefits: "Air purification",
    symptoms: ["yellow leaves", "root rot"],
    solution: "Reduce watering and provide indirect light",
    tags: ["Indoor", "Air Purifying"],
    emoji: "🌱"
  },

  {
    id: 3,
    name: "Money Plant",
    scientificName: "Epipremnum aureum",
    environment: "indoor",
    sun: "medium",
    water: "medium",
    difficulty: "easy",
    benefits: "Decorative and air purifying",
    symptoms: ["yellow leaves", "wilting"],
    solution: "Provide indirect sunlight and moderate watering",
    tags: ["Indoor", "Easy Care"],
    emoji: "🍃"
  },

  {
    id: 4,
    name: "Rose",
    scientificName: "Rosa",
    environment: "outdoor",
    sun: "high",
    water: "medium",
    difficulty: "medium",
    benefits: "Beautiful flowers",
    symptoms: ["leaf curl", "yellow leaves"],
    solution: "Provide sunlight and regular watering",
    tags: ["Flower", "Outdoor"],
    emoji: "🌹"
  },

  {
    id: 59,
    name: "Tomato Plant",
    scientificName: "Solanum lycopersicum",
    environment: "outdoor",
    sun: "high",
    water: "medium",
    difficulty: "medium",
    benefits: "Edible vegetables",
    symptoms: ["leaf curl", "yellow leaves", "fruit cracking"],
    solution: "Maintain consistent watering and sunlight",
    tags: ["Vegetable", "Outdoor"],
    emoji: "🍅"
  },

  {
    id: 60,
    name: "Chilli Plant",
    scientificName: "Capsicum annuum",
    environment: "outdoor",
    sun: "high",
    water: "medium",
    difficulty: "easy",
    benefits: "Edible peppers",
    symptoms: ["leaf curl", "yellow leaves", "wilting"],
    solution: "Provide sunlight and consistent moisture",
    tags: ["Vegetable", "Outdoor"],
    emoji: "🌶️"
  }
];

// ===============================
// HOME / API TEST
// ===============================

app.get("/api", (req, res) => {
  res.json({
    success: true,
    message: "NurseryIQ backend is running 🌱",
    totalPlants: plants.length
  });
});

// ===============================
// GET ALL PLANTS
// ===============================

app.get("/api/plants", (req, res) => {
  try {
    res.json({
      success: true,
      count: plants.length,
      plants: plants
    });
  } catch (error) {
    console.error("Plants error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to load plants"
    });
  }
});

// ===============================
// SEARCH / FILTER PLANTS
// ===============================

app.get("/api/plants/search", (req, res) => {
  try {
    const {
      search = "",
      category = "",
      sunlight = "",
      water = ""
    } = req.query;

    const searchText = search.toLowerCase().trim();

    const matches = plants.filter((plant) => {

      const searchMatch =
        !searchText ||
        plant.name.toLowerCase().includes(searchText) ||
        plant.scientificName.toLowerCase().includes(searchText);

      const categoryMatch =
        !category ||
        (plant.tags &&
          plant.tags.some(
            tag => tag.toLowerCase() === category.toLowerCase()
          ));

      const sunlightMatch =
        !sunlight ||
        plant.sun === sunlight;

      const waterMatch =
        !water ||
        plant.water === water;

      return (
        searchMatch &&
        categoryMatch &&
        sunlightMatch &&
        waterMatch
      );
    });

    res.json({
      success: true,
      count: matches.length,
      plants: matches
    });

  } catch (error) {
    console.error("Search error:", error);

    res.status(500).json({
      success: false,
      message: "Plant search failed"
    });
  }
});

// ===============================
// PLANT RECOMMENDATION
// ===============================

app.post("/api/recommend", (req, res) => {
  try {

    const {
      environment = "",
      sunlight = "",
      water = "",
      experience = ""
    } = req.body;

    const matches = plants.filter((plant) => {

      const environmentMatch =
        !environment ||
        plant.environment === environment;

      const sunlightMatch =
        !sunlight ||
        plant.sun === sunlight;

      const waterMatch =
        !water ||
        plant.water === water;

      const experienceMatch =
        !experience ||
        plant.difficulty === experience;

      return (
        environmentMatch &&
        sunlightMatch &&
        waterMatch &&
        experienceMatch
      );
    });

    res.json({
      success: true,
      count: matches.length,
      plants: matches
    });

  } catch (error) {

    console.error("Recommendation error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to generate recommendation"
    });
  }
});

// ===============================
// PLANT DIAGNOSIS
// ===============================

app.post("/api/diagnose", (req, res) => {
  try {

    const symptoms = Array.isArray(req.body.symptoms)
      ? req.body.symptoms
      : [];

    if (symptoms.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Please select at least one symptom"
      });
    }

    const results = plants
      .map((plant) => {

        const matchedSymptoms =
          plant.symptoms.filter((symptom) =>
            symptoms
              .map(s => s.toLowerCase())
              .includes(symptom.toLowerCase())
          );

        return {
          ...plant,
          matchedSymptoms,
          matchCount: matchedSymptoms.length
        };

      })
      .filter(plant => plant.matchCount > 0)
      .sort((a, b) => b.matchCount - a.matchCount);

    res.json({
      success: true,
      count: results.length,
      plants: results
    });

  } catch (error) {

    console.error("Diagnosis error:", error);

    res.status(500).json({
      success: false,
      message: "Diagnosis failed"
    });
  }
});
app.post("/api/recommend", (req, res) => {
    const { environment, sunlight, water, experience } = req.body;

    let matches = plants.filter(plant => {

        const environmentMatch =
            !environment || plant.environment === environment;

        const sunMatch =
            !sunlight || plant.sun === sunlight;

        const waterMatch =
            !water || plant.water === water;

        const experienceMatch =
            !experience || plant.difficulty === experience;

        return (
            environmentMatch &&
            sunMatch &&
            waterMatch &&
            experienceMatch
        );
    });

    res.json({
        success: true,
        plants: matches
    });
});
// ===============================
// START SERVER
// ===============================

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});